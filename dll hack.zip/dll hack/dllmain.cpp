#include <windows.h>
#include <stdio.h>
#include "patch.h"

PROC g_proc_0040D02A;
int __stdcall change_left_draw_color(DWORD a, DWORD id)
{
    int original = ((int (*)(DWORD, DWORD))g_proc_0040D02A)(a, id);

    char msg[MAX_PATH];
    sprintf(msg, "Color ID = %d", id);
    MessageBox(NULL, msg, "Test", MB_OK);

    return original;
}

void hook(int adr, PROC* p, char* func)
{
    *p = patch_call((char*)adr, func);
}

bool dll_loaded = false;

extern "C" __declspec(dllexport) void dll_init()
{
    if (!dll_loaded)
    {
        hook(0x0040D02A, &g_proc_0040D02A, (char*)change_left_draw_color);
        dll_loaded = true;
    }
}

BOOL WINAPI DllMain(HINSTANCE hinstDLL, DWORD ul_reason_for_call, LPVOID) 
{
	if (ul_reason_for_call == DLL_PROCESS_ATTACH)dll_init();
	return TRUE; 
}