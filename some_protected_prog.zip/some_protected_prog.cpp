﻿#include <iostream>
#include <fstream>

using namespace std;

int a = 0;
string p = "";
char key[] = "\x27\x7D\x17\x46\x6F\x3C\x4B\x71";

void not_function()
{
    __asm
    {
        mov eax, DWORD ptr[0xC9D4D9B7]
        mov eax, DWORD ptr[0xC7C9D7D6]
        mov eax, DWORD ptr[0xD4C8C9D6]
        mov eax, DWORD ptr[0x64D7D7C5]
    }
}

bool check_pass()
{
    int i = 0;
    int k = 0;
    int kk = 1;
    void* v = not_function;
    if (p.length() != 15)return false;
    while (kk<=4)
    {
        while (k < 4 * kk)
        {
            if ((int)p[i] != (int)(*(unsigned char*)((int)v + k + kk)) - 0x64) return false;
            i++;
            k++;
        }
        kk++;
    }
    return true;
}

bool check_key()
{
    string fp = "";
    ifstream fin("license.key");
    if (!fin.is_open())
    {
        cout << "key file not found\n";
        return false;
    }
    fin >> fp;
    fin.close();
    for (int i = 0; i < 8; i++)
    {
        if (key[i] != (fp[2 * i] ^ fp[2 * i + 1]))return false;
    }
    return true;
}

void print_menu()
{
    char ver[] = "(demo version)";
    cout << endl << "some_program " << (check_key() ? " " : ver);
    if (check_pass())cout << "+correct password!";
    cout << endl;
    cout << "--------------------------" << endl;
    cout << "current argument = " << a << endl;
    cout << "--------------------------" << endl;
    cout << "1 - input new argument" << endl;
    cout << "2 - argument +1" << endl;
    cout << "3 - argument -1" << endl;
    cout << "4 - argument x2" << endl;
    if (!check_pass())cout << "5 - input password" << endl;
}

int main()
{
    int m = 0;
    bool no_exit = true;
    while (no_exit)
    {
        char c;
        print_menu();
        cin >> c;
        m = (int)(c - 0x30);
        switch (m)
        {
        case 1:
        {
            string s;
            cin >> s;
            a = atoi(s.c_str());
            break; 
        }
        case 2:
        {
            a = a++;
            break;
        }
        case 3:
        {
            if (check_key())a = a--;
            else cout << "this function required license key!" << endl;
            break;
        }
        case 4:
        {
            if (check_pass())a *= 2;
            else cout << "this function required inputting correct password!" << endl;
            break;
        }
        case 5:
        {
            cin >> p;
            cout << check_pass() << endl;
            break;
        }
        default:no_exit = false; break;
        }
    }
    return 0;
}